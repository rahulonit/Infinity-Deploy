# License

Infinity Deploy is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 2 of the License, or (at your option) any later version.

Infinity Deploy is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this software. If not, see <https://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.

SPDX-License-Identifier: GPL-2.0-or-later

Copyright © 2026 Infinity.
